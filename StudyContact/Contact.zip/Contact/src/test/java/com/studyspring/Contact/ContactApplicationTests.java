package com.studyspring.Contact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactApplicationTests {

	@Test
	void contextLoads() {
	}

}
